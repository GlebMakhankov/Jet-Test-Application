const files = new webix.DataCollection();

export default files;
