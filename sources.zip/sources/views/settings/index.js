export default {
	template: "Settings page", css: "webix_shadow_medium app_start"
};
